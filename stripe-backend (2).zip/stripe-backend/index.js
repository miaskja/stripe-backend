const express = require('express');
const app = express();
const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const cors = require('cors');
app.use(cors());

app.get('/monthly-summary', async (req, res) => {
  try {
    const subscriptions = await stripe.subscriptions.list({ status: 'active', limit: 100 });
    const total = subscriptions.data.reduce((sum, s) => sum + (s.plan.amount || 0), 0);
    res.json({
      amount: (total / 100).toFixed(2),
      count: subscriptions.data.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));